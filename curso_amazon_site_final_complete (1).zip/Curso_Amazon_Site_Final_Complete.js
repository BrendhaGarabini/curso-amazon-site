
// Pacote Final do Site - Curso Online Ganhe com Amazon
// Instruções:
// 1. Baixe este código e faça upload diretamente no Vercel.
// 2. Configure o domínio e o envio de e-mails.
// 3. O site estará pronto para uso.

// Arquivo package.json configurado para React/Next.js
{
  "name": "curso-amazon-site",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "next": "^12.3.1"
  }
}

// Código React para o site
import React, { useState } from 'react';

export default function Home() {
  const [accessGranted, setAccessGranted] = useState(false);
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [email, setEmail] = useState("");

  const handlePayment = (method) => {
    if (method === 'paypal') {
      window.open('https://www.paypal.com', '_blank');
      setAccessGranted(true);
      setPaymentConfirmed(true);
    } else if (method === 'stripe') {
      window.open('https://checkout.stripe.com', '_blank');
      setAccessGranted(true);
      setPaymentConfirmed(true);
    }
  };

  return (
    <div>
      <h1>Curso Online - Ganhe com Amazon</h1>
      <input type="email" placeholder="Seu Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <button onClick={() => handlePayment('paypal')}>Pagar com PayPal</button>
      <button onClick={() => handlePayment('stripe')}>Pagar com Cartão</button>
      {paymentConfirmed && <p>Pagamento Confirmado! Acesse o curso.</p>}
    </div>
  );
}
