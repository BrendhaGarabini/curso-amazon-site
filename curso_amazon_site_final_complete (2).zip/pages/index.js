
import React, { useState } from 'react';

export default function Home() {
  const [accessGranted, setAccessGranted] = useState(false);
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [email, setEmail] = useState("");

  const handlePayment = (method) => {
    if (method === 'paypal') {
      window.open('https://www.paypal.com', '_blank');
      setAccessGranted(true);
      setPaymentConfirmed(true);
    } else if (method === 'stripe') {
      window.open('https://checkout.stripe.com', '_blank');
      setAccessGranted(true);
      setPaymentConfirmed(true);
    }
  };

  return (
    <div>
      <h1>Curso Online - Ganhe com Amazon</h1>
      <input type="email" placeholder="Seu Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <button onClick={() => handlePayment('paypal')}>Pagar com PayPal</button>
      <button onClick={() => handlePayment('stripe')}>Pagar com Cartão</button>
      {paymentConfirmed && <p>Pagamento Confirmado! Acesse o curso.</p>}
    </div>
  );
}
